package com.example.pelis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PelisApplication {

	public static void main(String[] args) {
		SpringApplication.run(PelisApplication.class, args);
	}

}

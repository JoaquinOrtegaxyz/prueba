package com.example.pelis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PelisApplicationTests {

	@Test
	void contextLoads() {
	}

}
